﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoReadMe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {

            //global strings to use it later to create the file
            string strConfigFile = @"C:\ProgramData\DIP\Xe\2.0.0.888\XE01.cfg";
            string strpath = string.Empty;
            string strLogFile = string.Empty;
            string strToZipFolder = string.Empty;// folder name to zip
            string strToZipFolderFullPath = string.Empty;// full path of the folder to zip
            string root = string.Empty; //actual path where the files will go to
            string root2 = string.Empty; //actual path where the TestingLog will go to.
            string strNewLocLog = string.Empty; // new location for the LogFile.
            string strNewLocConfig = string.Empty;// new location for the Config file.


            string strediDateTimeInspection = string.Empty;
            string strserviceSegmentDateTimeInspection = string.Empty;
            string strvdaDateTimeInspection = string.Empty;
            string strserviceSegmentReferenceInspection = string.Empty;
            string strvdaReferenceInspection = string.Empty;
            string strhseDateTimeInspection = string.Empty;
            string strhseWhitespaceInspection = string.Empty;
            string strhseCompareTrimFields = string.Empty;

            string strEDI_DC40_18 = string.Empty;
            string strEDI_DC40_24 = string.Empty;
            string strEDI_DC40_27 = string.Empty;
            string strEDI_DC40_30 = string.Empty;
            string strEDI_DC40_31 = string.Empty;
            string strEDI_DC40_32 = string.Empty;

            int countcirs = 0;
            int countdirs = 0;
            int lineCount = 0;
            string strLocation = string.Empty;
            string strLineThree = string.Empty;
            string TotalFiles = string.Empty;
            string pathss = string.Empty;
            pathss = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            //Test runner Inpection in strings

            //the following is collecting the last folder created when last used the test runner
            try
            {


                string[] dirs = Directory.GetDirectories(@"C:\ProgramData\DIP\Xe\2.0.0.888\TestRuns");
                //Console.WriteLine("The number of directories = {0}.", dirs.Length);
                countcirs = dirs.Length;// how many subfolders are in the folder.

                foreach (string dir in dirs)
                {
                    countdirs++;
                    if (countdirs == countcirs)
                    {
                        strpath = dir;
                        Console.WriteLine(strpath);
                        strLogFile = strpath + @"\log.txt";
                    }

                }
            }
            catch { }
            //ends here collecting the last folder created when last used the test runner

            // following code reads the log file.


            // Display the file contents to the console. Variable text is a string.
            // System.Console.WriteLine("Contents of WriteText.txt = {0}", text);

            // Example #2
            // Read each line of the file into a string array. Each element
            // of the array is one line of the file.
            if (File.Exists(strLogFile))
            {
                // This path is a file
                //ProcessFile(strLogFile);
                string[] lines = System.IO.File.ReadAllLines(strLogFile);//path for the latest folder 

                //string[] lines = System.IO.File.ReadAllLines(strLogFile);//path for the latest folder 

                // Display the file contents by using a foreach loop.
                //System.Console.WriteLine("Contents of WriteLines2.txt = ");
                foreach (string line in lines)
                {


                    // following gets the map name
                    lineCount++;
                    if (lineCount == 3)
                    {
                        if (line.Contains("Testing map"))
                        {
                            strLineThree = line;
                            strLineThree = strLineThree.Remove(0, 43);

                            strLineThree = strLineThree.Substring(0, strLineThree.IndexOf("]"));

                            // Use a tab to indent each line of the file.
                            //Console.WriteLine("Map Name:");
                            //Console.WriteLine("•    " + strLineThree);
                        }
                    }
                        if (lineCount == 4)
                        {
                            if (line.Contains("Testing map"))
                            {
                                strLineThree = line;
                                strLineThree = strLineThree.Remove(0, 45);

                                strLineThree = strLineThree.Substring(0, strLineThree.IndexOf("]"));

                                // Use a tab to indent each line of the file.
                                //Console.WriteLine("Map Name:");
                                //Console.WriteLine("•    " + strLineThree);
                            }

                        }
                    //map name ends here

                    if (line.Contains("Trace      Examining directory ["))
                    {
                        strLocation = line;
                        strLocation = strLocation.Remove(0, 53);
                        strLocation = strLocation.Substring(0, strLocation.IndexOf("]"));
                    }

                    if (line.Contains("Total files:"))
                    {
                        //Console.WriteLine("Total map files:");
                        TotalFiles = line;

                        TotalFiles = TotalFiles.Remove(0, 46);
                        /*
                        Console.WriteLine(TotalFiles);

                        Console.WriteLine("Test Runner used (if not, state the reason):");
                        Console.WriteLine("•    Yes");
                        Console.WriteLine("List of Map files tested: ");
                        Console.WriteLine("•	Tested all files in the folder (" + strLocation + ") at time of testing");
                        Console.WriteLine("List of fields excluded in the config file (and reasons):");
                        */
                    }

                    //geting the folder location

                    if (line.Contains("Trace      Examining directory ["))
                    {
                        // Console.WriteLine(line);
                    }

                }



                string[] ConfigLines = System.IO.File.ReadAllLines(@"C:\ProgramData\DIP\Xe\2.0.0.888\XE01.cfg");//path for the latest folder 

                //System.Console.WriteLine("Contents of Config File ");
                foreach (string ConfigLine in ConfigLines)
                {
                    //if (ConfigLine.Contains("ediDateTimeInspection"))
                    //{

                    if (!ConfigLine.Contains("false") && ConfigLine.Contains("Inspection"))
                    {
                        //Console.WriteLine(ConfigLine);


                        if (ConfigLine.Contains("ediDateTimeInspection"))
                        {
                            strediDateTimeInspection = ConfigLine;
                        }
                        if (ConfigLine.Contains("serviceSegmentDateTimeInspection"))
                        {
                            strserviceSegmentDateTimeInspection = ConfigLine + " - ignores the service segment date times as the map will use the system date and time";
                        }
                        if (ConfigLine.Contains("vdaDateTimeInspection"))
                        {
                            strvdaDateTimeInspection = ConfigLine;
                        }
                        if (ConfigLine.Contains("serviceSegmentReferenceInspection"))
                        {
                            strserviceSegmentReferenceInspection = ConfigLine;
                        }
                        if (ConfigLine.Contains("vdaReferenceInspection"))
                        {
                            strvdaReferenceInspection = ConfigLine + " This field affects ‘51100050 – Transmission number (old)’ and ‘51100060 – Transmission number (new)’ and these are ignored as the counter in our output and the expected output will mismatch as they will both be different values";
                            //Console.WriteLine(strvdaReferenceInspection);
                        }
                        if (ConfigLine.Contains("hseDateTimeInspection"))
                        {
                            strhseDateTimeInspection = ConfigLine;
                        }
                        if (ConfigLine.Contains("hseWhitespaceInspection"))
                        {
                            strhseWhitespaceInspection = ConfigLine;
                        }
                        if (ConfigLine.Contains("hseCompareTrimFields"))
                        {
                            strhseCompareTrimFields = ConfigLine;
                        }
                        if (ConfigLine.Contains("hseInspection") && ConfigLine.Contains("EDI_DC40,18"))
                        {
                            strEDI_DC40_18 = ConfigLine + " -EDI_DC40 - SNDPOR - We are using the SapControlRecord lookup Table";
                            //Console.WriteLine(strEDI_DC40_18);
                        }
                        if (ConfigLine.Contains("hseInspection") && ConfigLine.Contains("EDI_DC40,24"))
                        {
                            strEDI_DC40_24 = ConfigLine + "  - EDI_DC40-RCVPOR - We are using the SapControlRecord lookup Table";
                        }
                        if (ConfigLine.Contains("hseInspection") && ConfigLine.Contains("EDI_DC40,27"))
                        {
                            strEDI_DC40_27 = ConfigLine + " -EDI_DC40 - RCVPRN - We are using the SapControlRecord lookup Table";
                        }
                        if (ConfigLine.Contains("hseInspection") && ConfigLine.Contains("EDI_DC40,30"))
                        {
                            strEDI_DC40_30 = ConfigLine + " - EDI_DC40-CREDAT - We are using system date";
                        }
                        if (ConfigLine.Contains("hseInspection") && ConfigLine.Contains("EDI_DC40,31"))
                        {
                            strEDI_DC40_31 = ConfigLine + " - EDI_DC40-CRETIM - We are using system Time";
                        }
                        if (ConfigLine.Contains("hseInspection") && ConfigLine.Contains("EDI_DC40,32"))
                        {
                            strEDI_DC40_32 = ConfigLine + " - EDI_DC40-REFINT - We are mapping from the transmission number on the edi side";
                        }
                    }
                }
                //Console.WriteLine("     ");
                //Console.WriteLine("Any other information:");

                // the colde beloww will output the data collected with the code above into a ReadMe.Text file



            }

            else
            {
                pathss = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                FileInfo finfo = new FileInfo(pathss + "\\ReadMe.txt");
                finfo = new FileInfo(pathss + "\\ReadMe.txt");
                using (StreamWriter writer = finfo.CreateText())
                {
                    MessageBox.Show("ERROR no Log.txt File found inside the latest folder created by the Test runner");
                }

            }

            // END OF README.TXT FILE.





            //collecting the folder inside with the testfiles created by hte test runner
            string[] dirs2 = Directory.GetDirectories(strpath);
            //Console.WriteLine("The number of directories = {0}.", dirs2.Length);
            countcirs = dirs2.Length;// how many subfolders are in the folder.

            foreach (string di in dirs2)
            {
                strToZipFolder = di;
                strToZipFolderFullPath = di;
                Console.WriteLine(strToZipFolder);


                //Collect up to the last \



                int position = 0;
                string s1 = strToZipFolder;

                // Find the index of the soft hyphen.
                position = s1.LastIndexOf(@"\");
                if (position >= 0)
                {
                    //Console.WriteLine(s1.LastIndexOf(@"\", position, position + 1));
                    int iToZipFolder = s1.LastIndexOf(@"\", position, position + 1);
                    iToZipFolder++;

                    strToZipFolder = strToZipFolder.Remove(0, iToZipFolder);
                    //Console.WriteLine(strToZipFolder);
                }


                //collect up to the last \



                //Creating a new folder

                root = (pathss + @"\" + strToZipFolder);
                root2 = (root + "\\TestingLog");



                //Console.WriteLine("-------------------------------------------------------------");
                //Console.WriteLine(pathss);
                // If directory does not exist, create it. 
                if (!Directory.Exists(root))
                {
                    Directory.CreateDirectory(root);
                    Directory.CreateDirectory(root2);
                    MessageBox.Show(" Folder successfully created  - Please search for the folder  ( " + strToZipFolder + " ) on your desktop");
                }

                // If directory does exist, replace it with a new one.
                else if (Directory.Exists(root))
                {
                    Directory.Delete(root, true);
                    Directory.CreateDirectory(root);
                    Directory.CreateDirectory(root2);
                    MessageBox.Show(" Folder -" + strToZipFolder + "- successfully Replaced with new files - find it in you desktop");
                }

                // end of creating a new folder


                // copying the log to the new folder


                strNewLocLog = root2 + @"\log.txt";
                strNewLocConfig = root2 + @"\XE01.cfg";
                

                if (Directory.Exists(root))
                {
                    if (File.Exists(strLogFile))//copy the log file
                    {
                        File.Copy(strLogFile, strNewLocLog, true);
                    }
                    else
                    {
                        MessageBox.Show("could not find the log file  inside the folder  " + strLogFile);

                    }

                    if (File.Exists(strConfigFile))// copy the config file
                    {
                        File.Copy(strConfigFile, strNewLocConfig, true);
                    }


                    // ReadmeFile

                    FileInfo finfo = new FileInfo(root2 + "\\ReadMe.txt");
                    using (StreamWriter writer = finfo.AppendText())
                    {

                        writer.WriteLine("Map Name:");
                        writer.WriteLine("•    " + strLineThree);
                        writer.WriteLine(" ");
                        writer.WriteLine("Total map files:");
                        writer.WriteLine("•    " + TotalFiles);
                        writer.WriteLine("   ");
                        writer.WriteLine("Test Runner used (if not, state the reason):");
                        writer.WriteLine("•    Yes");
                        writer.WriteLine("   ");
                        writer.WriteLine("List of Map files tested: ");
                        writer.WriteLine("•	Tested all files in the folder (" + strLocation + ") at time of testing");
                        writer.WriteLine("   ");
                        writer.WriteLine("List of fields excluded in the config file (and reasons):");
                        if (!String.IsNullOrEmpty(strediDateTimeInspection))
                        {
                            writer.WriteLine(strediDateTimeInspection);
                        }

                        if (!String.IsNullOrEmpty(strserviceSegmentDateTimeInspection))
                        {
                            writer.WriteLine(strserviceSegmentDateTimeInspection);
                        }

                        if (!String.IsNullOrEmpty(strvdaDateTimeInspection))
                        {
                            writer.WriteLine(strvdaDateTimeInspection);
                        }

                        if (!String.IsNullOrEmpty(strserviceSegmentReferenceInspection))
                        {
                            writer.WriteLine(strserviceSegmentReferenceInspection);
                        }

                        if (!String.IsNullOrEmpty(strvdaReferenceInspection))
                        {
                            writer.WriteLine(strvdaReferenceInspection);
                        }

                        if (!String.IsNullOrEmpty(strhseDateTimeInspection))
                        {
                            writer.WriteLine(strhseDateTimeInspection);
                        }

                        if (!String.IsNullOrEmpty(strhseWhitespaceInspection))
                        {
                            writer.WriteLine(strhseWhitespaceInspection);
                        }

                        if (!String.IsNullOrEmpty(strhseCompareTrimFields))
                        {
                            writer.WriteLine(strhseCompareTrimFields);
                        }

                        if (!String.IsNullOrEmpty(strEDI_DC40_18))
                        {
                            writer.WriteLine(strEDI_DC40_18);
                        }

                        if (!String.IsNullOrEmpty(strEDI_DC40_24))
                        {
                            writer.WriteLine(strEDI_DC40_24);
                        }

                        if (!String.IsNullOrEmpty(strEDI_DC40_27))
                        {
                            writer.WriteLine(strEDI_DC40_27);
                        }

                        if (!String.IsNullOrEmpty(strEDI_DC40_30))
                        {
                            writer.WriteLine(strEDI_DC40_30);
                        }

                        if (!String.IsNullOrEmpty(strEDI_DC40_31))
                        {
                            writer.WriteLine(strEDI_DC40_31);
                        }

                        if (!String.IsNullOrEmpty(strEDI_DC40_32))
                        {
                            writer.WriteLine(strEDI_DC40_32);
                        }
                        writer.WriteLine("   ");
                        writer.WriteLine("Any other information:");
                    }
                    finfo = new FileInfo(root2 + "\\ReadMe.txt");
                    using (StreamWriter writer = finfo.CreateText())
                    {
                        writer.WriteLine("Map Name:");
                        writer.WriteLine("•    " + strLineThree);
                        writer.WriteLine(" ");
                        writer.WriteLine("Total map files:");
                        writer.WriteLine("•    " + TotalFiles);
                        writer.WriteLine("   ");
                        writer.WriteLine("Test Runner used (if not, state the reason):");
                        writer.WriteLine("•    Yes");
                        writer.WriteLine("   ");
                        writer.WriteLine("List of Map files tested: ");
                        writer.WriteLine("•	Tested all files in the folder (" + strLocation + ") at time of testing");
                        writer.WriteLine("   ");
                        writer.WriteLine("List of fields excluded in the config file (and reasons):");
                        if (!String.IsNullOrEmpty(strediDateTimeInspection))
                        {
                            writer.WriteLine(strediDateTimeInspection);
                        }

                        if (!String.IsNullOrEmpty(strserviceSegmentDateTimeInspection))
                        {
                            writer.WriteLine(strserviceSegmentDateTimeInspection);
                        }

                        if (!String.IsNullOrEmpty(strvdaDateTimeInspection))
                        {
                            writer.WriteLine(strvdaDateTimeInspection);
                        }

                        if (!String.IsNullOrEmpty(strserviceSegmentReferenceInspection))
                        {
                            writer.WriteLine(strserviceSegmentReferenceInspection);
                        }

                        if (!String.IsNullOrEmpty(strvdaReferenceInspection))
                        {
                            writer.WriteLine(strvdaReferenceInspection);
                        }

                        if (!String.IsNullOrEmpty(strhseDateTimeInspection))
                        {
                            writer.WriteLine(strhseDateTimeInspection);
                        }

                        if (!String.IsNullOrEmpty(strhseWhitespaceInspection))
                        {
                            writer.WriteLine(strhseWhitespaceInspection);
                        }

                        if (!String.IsNullOrEmpty(strhseCompareTrimFields))
                        {
                            writer.WriteLine(strhseCompareTrimFields);
                        }

                        if (!String.IsNullOrEmpty(strEDI_DC40_18))
                        {
                            writer.WriteLine(strEDI_DC40_18);
                        }

                        if (!String.IsNullOrEmpty(strEDI_DC40_24))
                        {
                            writer.WriteLine(strEDI_DC40_24);
                        }

                        if (!String.IsNullOrEmpty(strEDI_DC40_27))
                        {
                            writer.WriteLine(strEDI_DC40_27);
                        }

                        if (!String.IsNullOrEmpty(strEDI_DC40_30))
                        {
                            writer.WriteLine(strEDI_DC40_30);
                        }

                        if (!String.IsNullOrEmpty(strEDI_DC40_31))
                        {
                            writer.WriteLine(strEDI_DC40_31);
                        }

                        if (!String.IsNullOrEmpty(strEDI_DC40_32))
                        {
                            writer.WriteLine(strEDI_DC40_32);
                        }
                        writer.WriteLine("   ");
                        writer.WriteLine("Any other information:");
                    }
                    /*
                    using (StreamReader reader = finfo.OpenText())
                    {
                        Console.WriteLine(reader.ReadToEnd());
                    }
                    Console.Read();
                    */
                    //end of readme file


                    //collect new outputs and paste into the new folder 

                    // Put all file names in root directory into array.
                   string[] array1 = Directory.GetFiles(strToZipFolderFullPath);//, "*.edi"); // extension in This is case-insensitive.


                    bool bFiles = false;
                    int countOnlytxtFile = 0;
                    // Display all files.
                    //Console.WriteLine("--- Files: ---");
                    foreach (string name in array1)
                    {
                       
                        string extension = Path.GetExtension(name);
                        if (extension != ".txt" && extension != ".log")
                        {
                            bFiles = true;//if there are files in the folder torn the bool to true
                           

                        }
                        if (extension != ".txt" && extension != ".log" && bFiles)
                        {
                            //Console.WriteLine(e);
                            string fileName = System.IO.Path.GetFileName(name);
                            string destFile = System.IO.Path.Combine(root, fileName);
                            System.IO.File.Copy(name, destFile, true);
                        }
                        else if (!bFiles)
                        {
                            countOnlytxtFile++; //in order for the MessageBox to appear only one time
                            if (countOnlytxtFile == 1 )
                            { 
                            MessageBox.Show("There are no output files, please check if the test runner has produced any outputs.");
                        }
                        }
                        
                           
                        
                    }

                   
                    //collect new outputs and paste into the new folder 


                }


                //end of copying the log to the new folder

            }
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }
    }
}
